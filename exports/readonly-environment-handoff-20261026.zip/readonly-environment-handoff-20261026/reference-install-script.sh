#!/usr/bin/env bash
set -euo pipefail
cd /workspace/a_stock_sentiment_system
python3 -m venv .venv
.venv/bin/python -m pip install --cache-dir /workspace/.pip-cache -r requirements.txt PyYAML python-multipart pytest pytest-mock httpx
.venv/bin/python -m pip check
cd frontend
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
mkdir -p /workspace/stock-build
./node_modules/.bin/tailwindcss -c ./tailwind.config.cjs -i ./src/base.css -o /workspace/stock-build/app.css --minify
./node_modules/.bin/vite build --outDir /workspace/stock-build/workbench

