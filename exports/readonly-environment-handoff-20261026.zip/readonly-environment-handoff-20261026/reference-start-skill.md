Use the existing checkout /workspace/a_stock_sentiment_system. Each cloud task is isolated; do not create a Git worktree unless explicitly requested. Keep tracked source, tests, manifests, lockfiles and committed static assets unchanged.
Python 3.12 and Node 24 were validated. Dependencies are in .venv and frontend/node_modules. Build verification outputs are in /workspace/stock-build; the application serves its committed static assets. Do not use npm run build during onboarding because it overwrites tracked static files; use the output overrides in install_script.
From /workspace/a_stock_sentiment_system:
export AUTOMATION_ENABLED=false REALTIME_STRATEGY_EXTERNAL=true ELTDX_EMBEDDED_COLLECTOR_ENABLED=false TZ=Asia/Shanghai MPLCONFIGDIR=/workspace/.mplconfig OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
Start one worker: .venv/bin/python run_web.py --host 127.0.0.1 --port 8000
Run in a managed background terminal with logs; live processes must be restarted after snapshot restoration. Check existing service before starting another.
Readiness: request /login and assert HTTP 200 with 登录 in the HTML; request /static/workbench/workspace.js and /static/css/app.css and assert HTTP 200 with nonempty bodies. Use local requests only; no localhost preview links.
Representative tests: .venv/bin/python -m pytest tests/test_permissions.py tests/test_price_limit_utils.py tests/test_behavior_cycle.py tests/test_backtest_trailing_stop.py tests/test_agent_evidence.py tests/test_artifact_cache.py
Validated 28 passed. tests/test_screening_engine_lock_retry.py has two repository test defects: mocks reject the read_only keyword passed by core/infrastructure/duckdb_access.py; report separately without modifying tests.
This is the local development workflow without live market collection. No Redis is needed for one worker. Do not enable scheduled jobs or collectors by default. TUSHARE_TOKEN was absent and live data access was not validated. Real collection needs separately configured provider access, network destinations, and (for shared market services) Redis. Do not request secrets in chat or print credentials. Runtime databases initialize under ignored webdata paths.

